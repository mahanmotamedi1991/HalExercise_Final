﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalExercise
{
    class Program
    {
        static void Main(string[] args)
        {


            // Take the reference Point
            Console.WriteLine("Please insert the coordinates of ref point with this format >>>> x,y,z");
            Point3d rPoint = new Point3d();
            Point3d referencePoint = rPoint.takeReferencePoint(Console.ReadLine());
            // Take reference line
            Console.WriteLine("Press Enter to insert the coordinated of two end points of the reference line");
            Console.ReadLine();
            Console.WriteLine("Insert the coordinates of the start point >>>> x,y,z  press enter and after Insert the coordinates of the end point >>>> x,y,z press enter");
            Line rLine = new Line();
            Line referenceLine = rLine.TakeReferenceLine(Console.ReadLine(), Console.ReadLine());

            // Take reference polyline
            Console.WriteLine("Press Enter to insert the the points of the reference polyline");
            Console.WriteLine("Insert the number of points you want to insert");
            int pCount = int.Parse(Console.ReadLine());
            Polyline referencePolyline = Polyline.CreatePolyline(pCount);

            // Finding the Closest Point on reference line and the distance

            referenceLine.ComputeLineClosestPoint(referencePoint);
            Double dist = referenceLine.CoumputeLineClosestPointDistance(referencePoint);
            Console.WriteLine("The closest distance of the reference point from the reference line is {0}: ", Math.Abs(dist));

            // Evaluate the distance of the reference point from the reference polyline.

            List<Double> distances = new List<double>();
            // Taking the mimunim distance
             foreach (Line segment in referencePolyline.SegmentsList)

            {
                var distance = segment.CoumputeLineClosestPointDistance(referencePoint);
                distances.Add(distance);
            }

            Double minDistance = new Double();
             for(int i=0; i<distances.Count; i++)
            {
                for(int j= i+1; j<distances.Count-1; j++)
                {
                    if (distances[i] > distances[j])
                    {
                        break;
                    }
                    else
                    {
                        minDistance = distances[i];
                        
                    }
                }
            }
            Console.WriteLine("The Closest distance from reference point to reference Polyline is {0}", Math.Abs(minDistance));


            if(dist<=minDistance)
            {
                Console.WriteLine("The Final Closest distance from reference point to reference Polyline and reference line is {0}", Math.Abs(dist));

            }
            else
            {
                Console.WriteLine("The Final Closest distance from reference point to reference Polyline and reference line is {0}", Math.Abs(minDistance));
            }
           
        }

     

        
    }
}
    



