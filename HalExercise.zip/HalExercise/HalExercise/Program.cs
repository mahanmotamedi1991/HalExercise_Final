﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalExercise
{
    class Program
    {
        static void Main(string[] args)
        {


            // Take the reference Point
            Console.WriteLine("Please insert the coordinates of ref point with this format >>>> x,y,z");
            Point3d rPoint = new Point3d();
            Point3d referencePoint = rPoint.takeReferencePoint(Console.ReadLine());

            // Take the reference lines
            Console.WriteLine("Please type the number of reference lines you want to insert");
            int noReferenceLines = int.Parse(Console.ReadLine());
            List<Line> referenceLinesList = new List<Line>();
            for(int i=0; i<noReferenceLines; i++)
            {
                Console.WriteLine("Press Enter to insert the coordinated of two end points of the reference line no {0}",i);
                Console.ReadLine();
                Console.WriteLine("Insert the coordinates of the start point >>>> x,y,z  press enter and after Insert the coordinates of the end point >>>> x,y,z press enter");
                Line referenceLine = new Line(Console.ReadLine(), Console.ReadLine());
                referenceLinesList.Add(referenceLine);
            }


            // Take the reference polyline
            Console.WriteLine("Press Enter to insert the the points of the reference polyline");
            Console.WriteLine("Insert the number of points you want to insert");
            int pCount = int.Parse(Console.ReadLine());
            Polyline referencePolyline = Polyline.CreatePolyline(pCount);

            // Finding the Closest distances from reference point to reference lines 
            List<Double> closestDistancesToReferenceLines = new List<Double>();
            for (int i = 0; i < referenceLinesList.Count; i++)
            { 
                Double dist = referenceLinesList[i].CoumputeLineClosestPointDistance(referencePoint);
                closestDistancesToReferenceLines.Add(dist);
                Console.WriteLine("The closest distance of the reference point from the reference line no {0} is {1}: ",i, Math.Abs(dist));
            }

            //Finding the minimum distace to reference Lines

            Double closestDist = new double();
            int closestLineId = new int();
            for(int i=0; i<closestDistancesToReferenceLines.Count; i++)
            {
                for(int j =i+1; j<closestDistancesToReferenceLines.Count-1; j++)
                {
                    if(closestDistancesToReferenceLines[i]>closestDistancesToReferenceLines[j])
                    {
                        break;
                    }
                    else
                    {
                        closestDist = closestDistancesToReferenceLines[i];
                        closestLineId = i;
                    }
                }
            }

            // Evaluate the distances from reference point to the reference polyline segments.

            List<Double> polylineSegmentsClosestdistances = new List<double>();
            // Taking the mimunim distance
             foreach (Line segment in referencePolyline.SegmentsList)

            {
                var distance = segment.CoumputeLineClosestPointDistance(referencePoint);
                polylineSegmentsClosestdistances.Add(distance);
            }

            Double minSegmentsDistance = new Double();
            int closestSegmentId = new int();
             for(int i=0; i<polylineSegmentsClosestdistances.Count; i++)
            {
                for(int j= i+1; j<polylineSegmentsClosestdistances.Count-1; j++)
                {
                    if (polylineSegmentsClosestdistances[i] > polylineSegmentsClosestdistances[j])
                    {
                        break;
                    }
                    else
                    {
                        minSegmentsDistance = polylineSegmentsClosestdistances[i];
                        closestSegmentId = i;
                        
                    }
                }
            }
            Console.WriteLine("The Closest distance from reference point to reference Polyline is {0}", Math.Abs(minSegmentsDistance));


            if(closestDist<minSegmentsDistance)
            {
                Console.WriteLine("The final closest distance from reference point to reference Polyline and reference lines is {0} and the line no {1} is the closest line to the reference point", Math.Abs(closestDist),closestLineId);
                Point3d closesPoint = referenceLinesList[closestLineId].ComputeLineClosestPoint(referencePoint);
                Console.WriteLine("The closest point to the reference point is ({0},{1},{2}) which is positioned on the line no {3}", closesPoint.X, closesPoint.Y, closesPoint.Z, closestLineId);
            }
            if(minSegmentsDistance<closestDist)
            {
                Console.WriteLine("The final closest distance from reference point to reference polyline and reference lines is {0} and the reference polyline with it's segment no {1} is the closest item to the reference point", minSegmentsDistance, closestSegmentId);
                Point3d closestPoint = referencePolyline.SegmentsList[closestSegmentId].ComputeLineClosestPoint(referencePoint);
                Console.WriteLine("The closest point to the reference point is ({0},{1},{2}) which is positioned on the segment no {3} of the reference polyLine",closestPoint.X,closestPoint.Y,closestPoint.Z,closestSegmentId);
            }
      
        }

     

        
    }
}
    



