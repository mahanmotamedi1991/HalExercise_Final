﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalExercise
{
    class Point3d
    {
        public Double X { get; set; }
        public Double Y { get; set; }
        public Double Z { get; set; }
        public Point3d(Double x, Double y, Double z)
        {
            X = x;
            Y = y;
            Z = z;
        }
        
        public Point3d(String coordinates)
        {
            String[] coordinatesArray = coordinates.Split(',');
            Double a = Double.Parse(coordinatesArray[0]);
            Double b = Double.Parse(coordinatesArray[1]);
            Double c = Double.Parse(coordinatesArray[2]);

            X = a;
            Y = b;
            Z = c;
        }

        public Point3d()
        {

        }

        public Point3d takeReferencePoint(String coordinates)
        {
            Point3d refPoint = new Point3d(coordinates);
            Console.WriteLine("The refrence point is ({0},{1},{2})", refPoint.X, refPoint.Y, refPoint.Z);
            return refPoint;
        }

        public Double ComputeDistanceBetweenTwoPoints(Point3d p1, Point3d p2)
        {
            var x1 = p1.X;
            var x2 = p2.X;
            var y1 = p1.Y;
            var y2 = p2.Y;
            var z1 = p1.Z;
            var z2 = p2.Z;

            var distance = Math.Sqrt((Math.Pow((x2 - x1), 2)) + (Math.Pow((y2 - y1), 2)) + (Math.Pow((z2 - z1), 2)));

            return distance;

        }

        public Point3d TransformPoint (Point3d point, Vector3d tVector)
        {
            Point3d tPoint = new Point3d(point.X + tVector.X, point.Y + tVector.Y, point.Z + tVector.Z);

            return tPoint;

        }

    }
}
       
    

