﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalExercise
{
    class Vector3d
    {
        public Double X { get; set;}
        public Double Y { get; set;}
        public Double Z { get; set;}
        public Point3d VectorPoint { get; set;}

        public double Magnitude { get { return ComputeVectorMagnitude(); } }

        public Vector3d Unitized { get { return UnitizeVector(); } }

        public Vector3d (Double x, Double y, Double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        public Vector3d (Point3d vectorPoint)
        {
            VectorPoint = vectorPoint;
        }

        public Vector3d (Point3d p0, Point3d p1)
        {
            var X1 = p0.X;
            var X2 = p1.X;
            var Y1 = p0.Y;
            var Y2 = p1.Y;
            var Z1 = p0.Z;
            var Z2 = p1.Z;
           
            X = X2 - X1;
            Y = Y2 - Y1;
            Z = Z2 - Z1;

        }

        public Vector3d()
        {

        }

        // Method
        public static Double ComputeAngleBetweenTwoVectors(Vector3d v1, Vector3d v2)
        {
            var dotProduct = ComputeDotProductBetweenTwoVectors(v1, v2);
            var MagnitudeOne = v1.Magnitude;
            var MahnitudeTwo = v2.Magnitude;

            Double angle = Math.Acos(dotProduct / (MagnitudeOne * MahnitudeTwo))*(180/Math.PI);

            return angle;

        }
        public  Double ComputeVectorMagnitude()
        {
            Double Magnitude = Math.Sqrt((Math.Pow((X), 2)) + (Math.Pow((Y), 2)) + (Math.Pow((Z), 2)));

            return Magnitude;
        }

        public Vector3d UnitizeVector()
        {
            Vector3d vector = new Vector3d(X, Y, Z);
            Double vectorMagnitude = vector.Magnitude;
            Vector3d uVector = new Vector3d(vector.X / vectorMagnitude, vector.Y / vectorMagnitude, vector.Z / vectorMagnitude);
            return uVector;

        }


        public static Double ComputeDotProductBetweenTwoVectors(Vector3d v1, Vector3d v2)
        {
            Double dotProduct = (v1.X * v2.X) + (v1.Y * v2.Y) + (v1.Z * v2.Z);

            return dotProduct;
        }

        public  Vector3d CreateVectorFromTwoPoints (Point3d p1, Point3d p2)
        {
            var X1 = p1.X;
            var X2 = p2.X;
            var Y1 = p1.Y;
            var Y2 = p2.Y;
            var Z1 = p1.Z;
            var Z2 = p2.Z;

            Vector3d vector = new Vector3d(x: (X2 - X1), (Y2 - Y1), (Z2 - Z1));
            return vector;

        }
    }


}

