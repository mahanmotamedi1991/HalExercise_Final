﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalExercise
{
    class Polyline
    {
        public int PointCount { get; set; }
        public int SegmentCount { get; set; }
        public List<Point3d> PointsList { get; set; }

        public List<Line> SegmentsList { get { return CreatesegmentsList(); } }

        public Polyline(List<Point3d> pList)

        {

            PointsList = pList;

        }

        public List<Line> CreatesegmentsList()
        {
            List<Line> segmentsList = new List<Line>();

            for (int i = 0; i < PointsList.Count-1; i++)
            {

                Line segment = new Line(PointsList[i], PointsList[i + 1]);
                segmentsList.Add(segment);

            }
            return segmentsList;
        }

        public Polyline ()
        {

        }

        // Method

        public static Polyline CreatePolyline(int noOfPoints)
        {
            List<Point3d> polyPoints = new List<Point3d>();

            for (int i = 0; i < noOfPoints; i++)
            {
                
                Console.WriteLine("Insert the coordinates of point no {0} >>>> x,y,z", i);
                String coordiante = Console.ReadLine();
                String[] coordinatesArray = coordiante.Split(',');
                Double a = Double.Parse(coordinatesArray[0]);
                Double b = Double.Parse(coordinatesArray[1]);
                Double c = Double.Parse(coordinatesArray[2]);

                polyPoints.Add(new Point3d(a, b, c));
            }

            Polyline poly = new Polyline(polyPoints);
            Console.WriteLine("The reference polyline consist of : ");

            for (int i=0; i<polyPoints.Count; i++)
            {
                Console.WriteLine("({0},{1},{2})", polyPoints[i].X, polyPoints[i].Y, polyPoints[i].Z);
            }
         
            return poly;
            
        }

    }


}

