﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HalExercise
{
    class Line
    {
        //Cosntructor
        public Point3d StartPoint { get; set; }
        public Point3d EndPoint { get; set; }
        public double Length { get { return CalculateLength(); } }

        public Line(Point3d p1, Point3d p2)
        {
            StartPoint = p1;
            EndPoint = p2;
        }

        public Line()
        {
        }

        public Line(String stpCoordinates, String enpCoordinates)
        {

            StartPoint = new Point3d(stpCoordinates);
            EndPoint = new Point3d(enpCoordinates);
            Console.WriteLine("The reference Line is [({0},{1},{2}) , ({3},{4},{5})]", StartPoint.X, StartPoint.Y, StartPoint.Z, EndPoint.X, EndPoint.Y, EndPoint.Z);
            Console.WriteLine("The length of the reference line is {0}", Length);

        }
        // Method
        public Line TakeReferenceLine(String stpCoordinates, String enpCoordinates)
        {

            Point3d startPoint = new Point3d(stpCoordinates);
            Point3d endPoint = new Point3d(enpCoordinates);
            Line refLine = new Line(startPoint, endPoint);
            Console.WriteLine("The reference Line is [({0},{1},{2}) , ({3},{4},{5})]", startPoint.X, startPoint.Y, startPoint.Z, endPoint.X, endPoint.Y, endPoint.Z);
            Double length = refLine.Length;
            Console.WriteLine("The length of the reference line is {0}", length);
            return refLine;
        }

        public Double CalculateLength()
        {
            Double x1 = Math.Pow((EndPoint.X - StartPoint.X), 2);
            Double y1 = Math.Pow((EndPoint.Y - StartPoint.Y), 2);
            Double z1 = Math.Pow((EndPoint.Z - StartPoint.Z), 2);
            Double length = Math.Sqrt(x1 + y1 + z1);

            return length;

        }

        public Point3d ComputeLineClosestPoint(Point3d point)
        {

            var p0 = StartPoint;
            var p1 = EndPoint;
            var p2 = point;

            Vector3d vec0 = new Vector3d(p0, p1);
            Vector3d vec1 = new Vector3d(p0, p2);
            Vector3d vec2 = new Vector3d(p1, p0);
            Vector3d vec3 = new Vector3d(p1, p2);

            var angle0 = Vector3d.ComputeAngleBetweenTwoVectors(vec0, vec1);
            var angle1 = Vector3d.ComputeAngleBetweenTwoVectors(vec2, vec3);
    

            if (angle0 <= 90 && angle1 <= 90)
            {
                // Fiding the distance of reference point from reference line
                Point3d p = new Point3d();
                var length0 = p.ComputeDistanceBetweenTwoPoints(p0, p2);
                var distance =Math.Abs( Math.Sin(angle0) * length0);

                // Finding the Closest Point on reference line


                Double shiftMagnitude = Math.Tan(angle0) * length0;
                Vector3d uVec0 = vec0.Unitized;
                Vector3d shiftVector = new Vector3d(uVec0.X * shiftMagnitude, uVec0.Y * shiftMagnitude, uVec0.Z * shiftMagnitude);
                Point3d closestPoint = p0.TransformPoint(p0, shiftVector);
              
               // Console.WriteLine("The closest point on the reference line is ({0},{1},{2})", closestPoint.X, closestPoint.Y, closestPoint.Z);
                return closestPoint;

            }
            else
            {
                Double distanceOne = p0.ComputeDistanceBetweenTwoPoints(p0, p2);
                Double distanceTwo = p1.ComputeDistanceBetweenTwoPoints(p1, p2);

                if (distanceOne < distanceTwo)
                {
                    var distance = distanceOne;
                    Point3d closestPoint = p0;
                 //   Console.WriteLine("The closest point on the reference line is ({0},{1},{2})", closestPoint.X, closestPoint.Y, closestPoint.Z);
                    return closestPoint;
                }
                 if (distanceTwo < distanceOne)
                {
                    var distance = distanceTwo;
                    Point3d closestPoint = p1;
                   // Console.WriteLine("The closest point on the reference line is ({0},{1},{2})", closestPoint.X, closestPoint.Y, closestPoint.Z);
                    return closestPoint;
                }
                else
                {
                    var distance = distanceOne;
                    Point3d closestPoint = p0;
                //    Console.WriteLine("The closest point on the reference line is ({0},{1},{2})", closestPoint.X, closestPoint.Y, closestPoint.Z);
                    return closestPoint;
                }



            }
        }

        public Double CoumputeLineClosestPointDistance(Point3d point)
        {
            var p0 = StartPoint;
            var p1 = EndPoint;
            var p2 = point;

            Vector3d vec0 = new Vector3d(p0, p1);
            Vector3d vec1 = new Vector3d(p0, p2);
            Vector3d vec2 = new Vector3d(p1, p0);
            Vector3d vec3 = new Vector3d(p1, p2);

            var angle0 = Vector3d.ComputeAngleBetweenTwoVectors(vec0, vec1);
            var angle1 = Vector3d.ComputeAngleBetweenTwoVectors(vec2, vec3);


            if (angle0 <= 90 && angle1 <= 90)
            {
                // Fiding the distance of reference point from reference line
                Point3d p = new Point3d();
                var length0 = p.ComputeDistanceBetweenTwoPoints(p0, p2);
                var distance = Math.Sin(angle0) * length0;
              
                return distance;

            }
            else
            {
                Double distanceOne = p0.ComputeDistanceBetweenTwoPoints(p0, p2);
                Double distanceTwo = p1.ComputeDistanceBetweenTwoPoints(p1, p2);

                if (distanceOne < distanceTwo)
                {
                    var distance = distanceOne;
                 
                    return distance;
                }

                if (distanceTwo < distanceOne)
                {
                    var distance = distanceTwo;
                 
                    return distance;
                }
                else
                {
                    var distance = distanceOne;
                  
                    return distance;
                }
            }
        }
    }
}


    








